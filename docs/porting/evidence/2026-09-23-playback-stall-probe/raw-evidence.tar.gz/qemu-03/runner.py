import base64, gzip, json, re, secrets, sys, time
from pathlib import Path
import tools.riscv.physical_graphics_qemu_gate as physical
from tools.riscv.physical_graphics_qemu_gate import PhysicalGraphicsQemuOperations, _next_line
from tools.riscv.debian.rootfs.desktop_m5_qemu_gate import DesktopM5QemuOperations
from tools.riscv.debian.rootfs.debug_console_qemu_gate import DebugConsoleQemuOperations
from tools.riscv.debian.rootfs.rootfs_gate import GateConfig, GateFailure
from tools.riscv.debian.rootfs.systemd_m2_gate import orchestrate_systemd_m2_gate
from tools.riscv.debian.rootfs.gate_protocol import GateResult
from tools.riscv.debian.rootfs.browser_web_marionette_gate import _BILIBILI_PLAYBACK_SCRIPT

HERE=Path('/root/asterinas/target/playback-stall-20260923')
plan=json.loads(Path('/root/asterinas/target/qemu-stability-20260922/browser-release-plan.json').read_text())
a={x['name']:Path(x['path']) for x in plan['artifacts']}
config=GateConfig(kernel=a['kernel'],u_boot=a['u_boot'],dtb=a['qemu_dtb'],stage1_initramfs=a['initramfs'],root_image=a['root_image'],manifest=a['root_manifest'],packages_lock=a['packages_lock'],package_checksums=a['package_checksums'],output_directory=HERE/sys.argv[1],boot_timeout=300,command_timeout=90)
guest=(HERE/'guest.py').read_text().replace('__PROBE_SCRIPT__',repr(_BILIBILI_PLAYBACK_SCRIPT)).replace('__VIDEO__',repr(Path('tools/riscv/debian/rootfs/browser_m5.webm.base64').read_text()))
physical.physical_browser_start_command = lambda: '/run/asterinas-tools/g start-web'
class Ops(PhysicalGraphicsQemuOperations):
 def serial_observer(self, config, boot_number):
  parent=super().serial_observer(config,boot_number)
  def observe(payload):
   with (config.output_directory/'live.serial.log').open('ab') as log: log.write(payload)
   parent(payload)
  return observe
 def shell(self,serial,command,timeout=30):
  nonce=secrets.token_hex(12);cursor=serial.checkpoint();deadline=time.monotonic()+timeout
  serial.send((command+"; s=$?; printf '\\nCONTROL_%s status=%s uid=%s boot=%s\\n' "+nonce+" \"$s\" \"$(id -u)\" \"$(cat /proc/sys/kernel/random/boot_id)\"\n").encode(),deadline)
  while True:
   line,cursor=_next_line(serial,cursor,deadline)
   if line.startswith('CONTROL_'+nonce+' '):
    print(line,flush=True)
    if 'status=0 uid=0 boot=' not in line: raise GateFailure('control failed: '+line)
    return
 def run_protocol(self,session,config):
  DesktopM5QemuOperations.run_protocol(self,session,config)
  serial=session['serial']
  self._quiesce_external_services(serial,time.monotonic()+90)
  self._wait_for_local_graphics(serial,time.monotonic()+300)
  self._run_debug_console_probe(session,config)
  self._start_browser(serial,time.monotonic()+180)
  self._browser_pid=self._query_browser_pid(serial,time.monotonic()+90)
  self._wait_for_marionette(serial,time.monotonic()+300)
  encoded=base64.b64encode(gzip.compress(guest.encode())).decode()
  self.shell(serial,"printf '' > /run/playback.py.gz.b64")
  for offset in range(0,len(encoded),900): self.shell(serial,"printf '%s' '"+encoded[offset:offset+900]+"' >> /run/playback.py.gz.b64")
  self.shell(serial,"base64 -d /run/playback.py.gz.b64 | gzip -d > /run/playback.py")
  cursor=serial.checkpoint();deadline=time.monotonic()+240
  self.shell(serial,"(python3 -u /run/playback.py; printf 'PLAYBACK_EXIT status=%s\\n' \"$?\") > /run/playback.log 2>&1 & wait_noop=true")
  # Drain diagnostics through explicit shell commands, leaving the console free.
  released=False
  while time.monotonic()<deadline:
   self.shell(serial,'cat /run/playback.log',30)
   transcript=serial.transcript[cursor:]
   if b'"kind": "awaiting-host-control"' in transcript and not released:
    self.shell(serial,"test -d /proc/"+str(self._browser_pid)+" && python3 -c \"import urllib.request; print(urllib.request.urlopen('http://127.0.0.1:18765/release',timeout=5).read())\"")
    released=True
   if re.search(rb'^PLAYBACK_EXIT status=[0-9]+', transcript, re.M):
    if not re.search(rb'^PLAYBACK_EXIT status=0\r?\r?$', transcript, re.M): raise GateFailure('playback experiment failed')
    self.shell(serial,'true');return
   time.sleep(1)
  raise GateFailure('experiment deadline expired')
 def classify_transcript(self,transcript,**kwargs):
  return GateResult(passed=b'"kind": "complete", "value": "pass"' in transcript,reason='playback experiment incomplete',evidence=None)
 def publish(self,config,prepared,transcript,result):
  result['experiment']='local VP8 sandbox comparison and loopback HTTP MSE starvation/recovery'
  result['physical']=False
  DebugConsoleQemuOperations.publish(self,config,prepared,transcript,result)
with Ops(config) as ops:
 result=orchestrate_systemd_m2_gate(config,ops,classifier=ops.classify_transcript)
 print(json.dumps(result,indent=2),flush=True)
 sys.exit(0 if result['passed'] else 1)
