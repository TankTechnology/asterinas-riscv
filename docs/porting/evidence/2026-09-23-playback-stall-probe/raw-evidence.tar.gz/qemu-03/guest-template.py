import base64, json, sys, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
sys.path.insert(0, '/usr/lib/asterinas')
from browser_m5_marionette_gate import Marionette

SCRIPT = __PROBE_SCRIPT__
VIDEO = base64.b64decode(__VIDEO__)
release = threading.Event()
requested = threading.Event()
HTML = b'''<!doctype html><title>Playback isolation</title><video muted width=320 height=180></video><button onclick="this.textContent='clicked'">control</button><script>
const v=document.querySelector('video');
window.testState={ticks:0,events:{},phase:'init'};
setInterval(()=>testState.ticks++,100);
for(const n of ['playing','waiting','timeupdate','ended','error'])v.addEventListener(n,()=>testState.events[n]=(testState.events[n]||0)+1);
async function append(sb,bytes){await new Promise((resolve,reject)=>{sb.addEventListener('updateend',resolve,{once:true});sb.addEventListener('error',reject,{once:true});sb.appendBuffer(bytes);});}
async function stream(){
 const ms=new MediaSource();v.src=URL.createObjectURL(ms);
 await new Promise(r=>ms.addEventListener('sourceopen',r,{once:true}));
 const sb=ms.addSourceBuffer('video/webm; codecs="vp8"');
 await append(sb,await(await fetch('/clip')).arrayBuffer());
 testState.phase='buffered';
 const next=await(await fetch('/held')).arrayBuffer();
 sb.timestampOffset=sb.buffered.end(sb.buffered.length-1);
 await append(sb,next);ms.endOfStream();testState.phase='released';
}
if(location.pathname==='/stream')stream().catch(e=>testState.failure=String(e));
else v.src='/clip';
</script>'''
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  if self.path == '/release': release.set(); body=b'ok'
  elif self.path == '/held':
   requested.set()
   if not release.wait(60): self.send_error(504); return
   body=VIDEO
  elif self.path == '/clip': body=VIDEO
  else: body=HTML
  self.send_response(200); self.send_header('Content-Length',str(len(body)))
  self.send_header('Content-Type','video/webm' if self.path in ('/clip','/held') else 'text/html')
  self.end_headers(); self.wfile.write(body)
 def log_message(self,*args): pass
server=ThreadingHTTPServer(('127.0.0.1',18765),Handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
def emit(kind, value): print('PLAYBACK_EVIDENCE '+json.dumps({'kind':kind,'value':value}),flush=True)
client=Marionette('127.0.0.1',2828,120)
emit('session',client.command('WebDriver:NewSession',{'strictFileInteractability':True,'proxy':{'proxyType':'direct'}}))
def execute(script, *, fresh=True, sandbox='default'):
 client.set_timeout(20)
 response=client.command('WebDriver:ExecuteScript',{'script':script,'args':[],'newSandbox':fresh,'sandbox':sandbox,'line':1,'filename':'playback-isolation'})
 return response.get('value',response) if isinstance(response,dict) else response
def probe(fresh,sandbox): return json.loads(execute(SCRIPT,fresh=fresh,sandbox=sandbox))
def page(): return json.loads(execute('return JSON.stringify(window.wrappedJSObject.testState);'))
def navigate(path):
 client.set_timeout(30);client.command('WebDriver:Navigate',{'url':'http://127.0.0.1:18765/'+path})
def samples(label, fresh, sandbox):
 navigate('local?'+label)
 result=[]
 for i in range(4):
  s=probe(fresh,sandbox);result.append(s);emit(label,s)
  execute('return document.title;') # The read-only default sandbox must not clear playback state.
  time.sleep(.3)
 emit(label+'-page',page())
 return result
old=samples('fresh-default',True,'default')
fixed=samples('persistent-named',False,'asterinas-bilibili-playback')
assert any(s['currentTime'] and s['currentTime']>.5 for s in old), 'old probe: no playback'
assert all(s['playPromise']=='pending' and s['events']['playing']==0 for s in old), 'fresh sandbox hypothesis not reproduced'
assert any(s['playPromise']=='resolved' and (s['events']['playing'] or s['events']['timeupdate']) for s in fixed), 'persistent sandbox did not retain state'
emit('sandbox-comparison','pass')
navigate('stream')
deadline=time.monotonic()+30
while time.monotonic()<deadline:
 s=probe(False,'asterinas-bilibili-playback');p=page();emit('stream-before-release',{'probe':s,'page':p,'held_request':requested.is_set()})
 if requested.is_set() and s['currentTime'] and s['currentTime']>.5 and s['readyState']<=2 and p['events'].get('waiting',0): break
 time.sleep(.3)
else: raise RuntimeError('did not observe buffer starvation')
before=s['currentTime']; ticks=p['ticks']
emit('awaiting-host-control','ready')
while not release.wait(.2):
 if time.monotonic()>deadline+20: raise RuntimeError('host release did not arrive')
deadline=time.monotonic()+20
while time.monotonic()<deadline:
 s=probe(False,'asterinas-bilibili-playback');p=page();emit('stream-after-release',{'probe':s,'page':p})
 if s['currentTime']>before+.5 and p['ticks']>ticks and p['phase']=='released': break
 time.sleep(.3)
else: raise RuntimeError('playback did not resume')
execute("document.querySelector('button').click(); return document.querySelector('button').textContent;")
assert execute("return document.querySelector('button').textContent;")=='clicked'
emit('stream-recovery','pass')
client.command('WebDriver:DeleteSession');client.close();server.shutdown()
emit('complete','pass')
