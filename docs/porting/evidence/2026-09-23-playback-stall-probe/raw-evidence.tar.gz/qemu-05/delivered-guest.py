import base64, json, sys, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
sys.path.insert(0, '/usr/lib/asterinas')
from browser_m5_marionette_gate import Marionette

import runpy
production = runpy.run_path('/usr/lib/asterinas/browser-web-marionette-gate')
exec('def _playback_probe(client: Marionette) -> dict[str, object]:\n    # Promise handlers and event counters live on the sandbox\'s video wrapper.\n    # Keep that wrapper across samples, separate from read-only DOM snapshots\n    # that recreate the default sandbox.\n    response = client.command(\n        "WebDriver:ExecuteScript",\n        {\n            "script": _BILIBILI_PLAYBACK_SCRIPT,\n            "args": [],\n            "newSandbox": False,\n            "sandbox": "asterinas-bilibili-playback",\n            "line": 1,\n            "filename": "asterinas-bilibili-playback",\n        },\n    )\n    value = _script_value(response)\n    if not isinstance(value, str):\n        detail = repr(response)\n        if len(detail) > 256:\n            detail = detail[:253] + "..."\n        raise GateError(\n            "Bilibili playback script returned no JSON: "\n            f"response_type={type(response).__name__} response={detail}"\n        )\n    try:\n        parsed = json.loads(value)\n    except json.JSONDecodeError as error:\n        raise GateError("Bilibili playback script returned malformed JSON") from error\n    return _playback_sample_mapping(parsed)\n', production)
SCRIPT = "const video = document.querySelector('video');\nconst eventNames = [\n  'loadedmetadata', 'canplay', 'playing', 'timeupdate',\n  'waiting', 'stalled', 'ended', 'error'\n];\nconst emptyEvents = () => Object.fromEntries(eventNames.map(name => [name, 0]));\nconst sourceKind = source => {\n  if (typeof source !== 'string' || source === '') return 'none';\n  if (source.startsWith('blob:')) return 'blob';\n  if (source.startsWith('https://')) return 'https';\n  if (source.startsWith('http://')) return 'http';\n  return 'other';\n};\nconst finiteOrNull = value => Number.isFinite(value) ? value : null;\nif (video === null) {\n  return JSON.stringify({\n    url: location.href,\n    state: 'no-video',\n    currentSrc: '',\n    src: '',\n    sourceKind: 'none',\n    paused: null,\n    ended: null,\n    readyState: null,\n    networkState: null,\n    duration: null,\n    currentTime: null,\n    bufferedEnd: null,\n    videoWidth: null,\n    videoHeight: null,\n    errorCode: null,\n    errorMessage: null,\n    playPromise: 'not-started',\n    playError: null,\n    events: emptyEvents(),\n    lastEvent: null,\n    decodedFrames: null,\n    droppedFrames: null\n  });\n}\nlet state = video.__asterinasPlayback;\nif (state === undefined) {\n  state = {\n    playRequested: false,\n    playPromise: 'not-started',\n    playError: null,\n    events: emptyEvents(),\n    lastEvent: null\n  };\n  for (const name of eventNames) {\n    video.addEventListener(name, () => {\n      state.events[name] += 1;\n      state.lastEvent = name;\n    }, {passive: true});\n  }\n  video.__asterinasPlayback = state;\n}\nconst currentSrcBeforePlay = video.currentSrc || video.src || '';\nif (!state.playRequested &&\n    (currentSrcBeforePlay !== '' || video.readyState > 0 || video.networkState !== 0)) {\n  state.playRequested = true;\n  video.muted = true;\n  video.defaultMuted = true;\n  video.volume = 0;\n  video.autoplay = true;\n  video.playsInline = true;\n  video.setAttribute('muted', '');\n  video.setAttribute('playsinline', '');\n  try {\n    const promise = video.play();\n    if (promise !== undefined && promise !== null &&\n        typeof promise.then === 'function') {\n      state.playPromise = 'pending';\n      promise.then(\n        () => { state.playPromise = 'resolved'; },\n        error => {\n          state.playPromise = 'rejected';\n          state.playError = {\n            name: error && error.name ? String(error.name) : '',\n            message: error && error.message ? String(error.message) : ''\n          };\n        }\n      );\n    } else {\n      state.playPromise = 'resolved';\n    }\n  } catch (error) {\n    state.playPromise = 'rejected';\n    state.playError = {\n      name: error && error.name ? String(error.name) : '',\n      message: error && error.message ? String(error.message) : ''\n    };\n  }\n}\nlet bufferedEnd = null;\ntry {\n  if (video.buffered.length > 0) {\n    bufferedEnd = finiteOrNull(video.buffered.end(video.buffered.length - 1));\n  }\n} catch (_) {}\nlet decodedFrames = null;\nlet droppedFrames = null;\ntry {\n  if (typeof video.getVideoPlaybackQuality === 'function') {\n    const quality = video.getVideoPlaybackQuality();\n    if (quality && Number.isFinite(quality.totalVideoFrames)) {\n      decodedFrames = quality.totalVideoFrames;\n    }\n    if (quality && Number.isFinite(quality.droppedVideoFrames)) {\n      droppedFrames = quality.droppedVideoFrames;\n    }\n  }\n} catch (_) {}\nconst currentSrc = video.currentSrc || video.src || '';\nreturn JSON.stringify({\n  url: location.href,\n  state: 'video',\n  currentSrc,\n  src: video.src || '',\n  sourceKind: sourceKind(currentSrc),\n  paused: video.paused,\n  ended: video.ended,\n  readyState: video.readyState,\n  networkState: video.networkState,\n  duration: finiteOrNull(video.duration),\n  currentTime: finiteOrNull(video.currentTime),\n  bufferedEnd,\n  videoWidth: video.videoWidth,\n  videoHeight: video.videoHeight,\n  errorCode: video.error === null ? null : video.error.code,\n  errorMessage: video.error === null ? null : (video.error.message || null),\n  playPromise: state.playPromise,\n  playError: state.playError,\n  events: state.events,\n  lastEvent: state.lastEvent,\n  decodedFrames,\n  droppedFrames\n});"
VIDEO = base64.b64decode('GkXfo59ChoEBQveBAULygQRC84EIQoKEd2VibUKHgQJChYECGFOAZwEAAAAAAAJWEU2bdLpNu4tT\nq4QVSalmU6yBoU27i1OrhBZUrmtTrIHGTbuMU6uEElTDZ1OsggEiTbuMU6uEHFO7a1OsggJA7AEA\nAAAAAABZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\nAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVSalmoCrXsYMPQkBNgIRMYXZm\nV0GETGF2ZkSJiECPQAAAAAAAFlSua9euAQAAAAAAAE7XgQFzxYgAAAAAAAAAAZyBACK1nIN1bmSI\ngQCGhVZfVlA4g4EBI+ODhAvrwgDgkLCBoLqBWpqBAlWwhFW5gQFV7oEA7AEAAAAAAAACAAASVMNn\n0HNzzWPAi2PFiAAAAAAAAAABZ8iYRaOHRU5DT0RFUkSHi0xhdmMgbGlidnB4Z8ihRaOIRFVSQVRJ\nT05Eh5MwMDowMDowMS4wMDAwMDAwMDAAH0O2dUDD54EAo9aBAACA8AUAnQEqoABaAABHCIWFiIWE\niAICAnWqA/gCBpoT4Iaqk13EOqpNdxDqqTXcQ6qk13EOqpNdxBgA/v9NEv/8WFfxYV/FhX/xYV/8\n/M7txfzmAKOYgQDIABECAAcQ7AAYABhYL/QACICBAAAAo5iBAZAAEQIABxDsABgAGFgv9AAIgIEA\nAACjmIECWAARAgAHEOwAGAAYWC/0AAiAgQAAAKOYgQMgABECAAcQ7AAYABhYL/QACICBAAAAHFO7\na5G7j7OBALeK94EB8YIBd/CBAw==\n')
release = threading.Event()
requested = threading.Event()
HTML = b'''<!doctype html><title>Playback isolation</title><video muted width=320 height=180></video><button onclick="this.textContent='clicked'">control</button><script>
const v=document.querySelector('video');
window.testState={ticks:0,events:{},phase:'init'};
setInterval(()=>testState.ticks++,100);
for(const n of ['playing','waiting','timeupdate','ended','error'])v.addEventListener(n,()=>testState.events[n]=(testState.events[n]||0)+1);
async function append(sb,bytes){await new Promise((resolve,reject)=>{sb.addEventListener('updateend',resolve,{once:true});sb.addEventListener('error',reject,{once:true});sb.appendBuffer(bytes);});}
async function stream(){
 const ms=new MediaSource();v.src=URL.createObjectURL(ms);
 await new Promise(r=>ms.addEventListener('sourceopen',r,{once:true}));
 const sb=ms.addSourceBuffer('video/webm; codecs="vp8"');
 await append(sb,await(await fetch('/clip')).arrayBuffer());
 testState.phase='buffered';
 const next=await(await fetch('/held')).arrayBuffer();
 sb.timestampOffset=sb.buffered.end(sb.buffered.length-1);
 await append(sb,next);ms.endOfStream();testState.phase='released';
}
if(location.pathname==='/stream')stream().catch(e=>testState.failure=String(e));
else v.src='/clip';
</script>'''
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  if self.path == '/release': release.set(); body=b'ok'
  elif self.path == '/held':
   requested.set()
   if not release.wait(60): self.send_error(504); return
   body=VIDEO
  elif self.path == '/clip': body=VIDEO
  else: body=HTML
  self.send_response(200); self.send_header('Content-Length',str(len(body)))
  self.send_header('Content-Type','video/webm' if self.path in ('/clip','/held') else 'text/html')
  self.end_headers(); self.wfile.write(body)
 def log_message(self,*args): pass
server=ThreadingHTTPServer(('127.0.0.1',18765),Handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
def emit(kind, value): print('PLAYBACK_EVIDENCE '+json.dumps({'kind':kind,'value':value}),flush=True)
client=Marionette('127.0.0.1',2828,120)
emit('session',client.command('WebDriver:NewSession',{'strictFileInteractability':True,'proxy':{'proxyType':'direct'}}))
def execute(script, *, fresh=True, sandbox='default'):
 client.set_timeout(20)
 response=client.command('WebDriver:ExecuteScript',{'script':script,'args':[],'newSandbox':fresh,'sandbox':sandbox,'line':1,'filename':'playback-isolation'})
 return response.get('value',response) if isinstance(response,dict) else response
def probe(fresh,sandbox):
 if not fresh:
  client.set_timeout(20)
  return production['_playback_probe'](client)
 return json.loads(execute(SCRIPT,fresh=fresh,sandbox=sandbox))
def page(): return json.loads(execute('return JSON.stringify(window.wrappedJSObject.testState);'))
def navigate(path):
 client.set_timeout(30);client.command('WebDriver:Navigate',{'url':'http://127.0.0.1:18765/'+path})
def samples(label, fresh, sandbox):
 navigate('local?'+label)
 result=[]
 for i in range(4):
  s=probe(fresh,sandbox);result.append(s);emit(label,s)
  execute('return document.title;') # The read-only default sandbox must not clear playback state.
  time.sleep(.3)
 emit(label+'-page',page())
 return result
old=samples('fresh-default',True,'default')
fixed=samples('persistent-named',False,'asterinas-bilibili-playback')
assert any(s['currentTime'] and s['currentTime']>.5 for s in old), 'old probe: no playback'
assert all(s['playPromise']=='pending' and s['events']['playing']==0 for s in old), 'fresh sandbox hypothesis not reproduced'
assert any(s['playPromise']=='resolved' and (s['events']['playing'] or s['events']['timeupdate']) for s in fixed), 'persistent sandbox did not retain state'
emit('sandbox-comparison','pass')
navigate('stream')
deadline=time.monotonic()+30
while time.monotonic()<deadline:
 s=probe(False,'asterinas-bilibili-playback');p=page();emit('stream-before-release',{'probe':s,'page':p,'held_request':requested.is_set()})
 if requested.is_set() and s['currentTime'] and s['currentTime']>.5 and s['readyState']<=2 and p['events'].get('waiting',0): break
 time.sleep(.3)
else: raise RuntimeError('did not observe buffer starvation')
before=s['currentTime']; ticks=p['ticks']; waiting=s['events']['waiting']
assert waiting>=2, 'did not observe a new waiting event after playback'
# Prove the content actor and DOM respond while the media HTTP request is held.
assert execute("document.querySelector('button').click(); return document.querySelector('button').textContent;")=='clicked'
emit('starved-dom-control','pass')
emit('awaiting-host-control','ready')
while not release.wait(.2):
 if time.monotonic()>deadline+20: raise RuntimeError('host release did not arrive')
deadline=time.monotonic()+20
while time.monotonic()<deadline:
 s=probe(False,'asterinas-bilibili-playback');p=page();emit('stream-after-release',{'probe':s,'page':p})
 if s['currentTime']>before+.5 and p['ticks']>ticks and p['phase']=='released': break
 time.sleep(.3)
else: raise RuntimeError('playback did not resume')
execute("document.querySelector('button').click(); return document.querySelector('button').textContent;")
assert execute("return document.querySelector('button').textContent;")=='clicked'
emit('stream-recovery','pass')
client.command('WebDriver:DeleteSession');client.close();server.shutdown()
emit('complete','pass')
