import hashlib,json,math,os,re,shutil,signal,subprocess,time
from pathlib import Path
START=time.monotonic()
def emit(kind,value):
    print('LIFECYCLE '+json.dumps({'kind':kind,'elapsed':round(time.monotonic()-START,3),'value':value}),flush=True)
meta=__BUNDLE_META__
archive=Path('/opt/lmbench-runtime.tar.gz')
assert hashlib.sha256(archive.read_bytes()).hexdigest()==meta['archive_sha256']
subprocess.run(['tar','xzf',str(archive),'-C','/'],check=True,timeout=20)
bindir=Path(meta['package'])/'bin'
for name in ['lat_syscall','lat_proc','lat_pipe','lat_ctx','lat_sig','bw_mem','lat_mmap','lat_pagefault','hello']:
    assert hashlib.sha256((bindir/name).read_bytes()).hexdigest()==meta['binary_sha256'][name],name
emit('identity',{'kernel':os.uname().release,'arch':os.uname().machine,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'bundle':meta['archive_sha256']})
subprocess.run(['systemctl','stop','asterinas-desktop-m5.service'],check=True,timeout=6)
fixture=Path('/tmp/lmbench-basic-file');fixture.write_bytes(b'x'*(1024*1024))
shutil.copyfile(bindir/'hello','/tmp/hello');Path('/tmp/hello').chmod(0o755)
for cmd in [['/tmp/hello'],['/bin/sh','-c','/tmp/hello']]:
    p=subprocess.run(cmd,env={},capture_output=True,text=True,timeout=3)
    assert p.returncode==0 and 'hello' in p.stdout.lower(),(cmd,p.returncode,p.stdout,p.stderr)
    emit('exec-preflight',{'argv':cmd,'status':p.returncode,'stdout':p.stdout})
common=['-P','1','-W','0','-N','1']
cases=[]
for mode in ['null','read','write','stat','fstat','open']:
    args=['lat_syscall']+common+[mode]
    if mode in ['stat','fstat','open']:args.append(str(fixture))
    cases.append(('syscall-'+('getppid' if mode=='null' else mode),args,r'(Simple [^\n]+): ([0-9.]+) microseconds'))
for mode in ['fork','exec','shell']:
    cases.append(('process-'+mode,['lat_proc']+common+[mode],r'(Process [^\n]+): ([0-9.]+) microseconds'))
cases += [('pipe',['lat_pipe']+common,r'(Pipe latency): ([0-9.]+) microseconds'),('context-switch-2',['lat_ctx']+common+['-s','0','2'],r'(?m)^2\s+([0-9.]+)\s*$')]
for mode in ['install','catch']:
    cases.append(('signal-'+mode,['lat_sig']+common+[mode],r'([^\n]+): ([0-9.]+) microseconds'))
for mode in ['rd','wr','cp']:
    cases.append(('memory-'+mode,['bw_mem']+common+['1m',mode],r'(?m)^1\.[0-9]+\s+([0-9.]+)\s*$'))
cases += [('mmap',['lat_mmap']+common+['1m',str(fixture)],r'(?m)^1\.[0-9]+\s+([0-9.]+)\s*$'),('pagefault',['lat_pagefault']+common+[str(fixture)],r'([^\n]+): ([0-9.]+) microseconds')]
env=os.environ.copy();env.update(ENOUGH='10000',LC_ALL='C')
failed=[]
for name,args,pattern in cases:
    argv=[str(bindir/args[0])]+args[1:];start=time.monotonic()
    emit('case-start',{'name':name,'argv':argv})
    p=subprocess.Popen(argv,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
    timeout=False
    try:stdout,stderr=p.communicate(timeout=10)
    except subprocess.TimeoutExpired:
        timeout=True;os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate(timeout=3)
    found=re.search(pattern,stdout+stderr)
    passed=p.returncode==0 and not timeout and found is not None and math.isfinite(float(found.groups()[-1])) and float(found.groups()[-1])>0
    record={'name':name,'argv':argv,'elapsed':round(time.monotonic()-start,3),'status':p.returncode,'timeout':timeout,'stdout':stdout,'stderr':stderr,'passed':passed}
    emit('case-result',record)
    if not passed:
        failed.append(name)
        break
emit('complete',{'passed':not failed,'failed':failed,'planned_cases':len(cases)})
assert not failed,failed
