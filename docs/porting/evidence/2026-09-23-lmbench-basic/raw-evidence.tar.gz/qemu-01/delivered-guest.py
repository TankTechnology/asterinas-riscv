import hashlib,json,math,os,re,shutil,signal,subprocess,time
from pathlib import Path
START=time.monotonic()
def emit(kind,value):
    print('LIFECYCLE '+json.dumps({'kind':kind,'elapsed':round(time.monotonic()-START,3),'value':value}),flush=True)
meta={'source_rev': 'afb47eddaf10a411c1ea3cb64965461f1308a6ea', 'package': '/nix/store/nx5i8n4dvz49qbh2gglzlnbvqsd9qfxp-lmbench-riscv64-unknown-linux-gnu-0.1.0', 'closure': ['/nix/store/hjwj9xg03xh3bx00z3bywbzk1blcj7kv-libgcc-riscv64-unknown-linux-gnu-14.2.1.20250322', '/nix/store/g96gza0vib44i6vbc87b3rgg74i40zp3-glibc-riscv64-unknown-linux-gnu-2.40-66', '/nix/store/60hfq3778qdh0qr52ym6zpa2wvl971kk-openssl-riscv64-unknown-linux-gnu-3.4.1', '/nix/store/c9gbaxykamd9kmdi76csyx8qpj1kzdy1-keyutils-riscv64-unknown-linux-gnu-1.6.3-lib', '/nix/store/mxsmimjq61jjx3jzl0bs3bjc1z2b7jin-krb5-riscv64-unknown-linux-gnu-1.21.3-lib', '/nix/store/vbi5g3f0msb34kdqsfqiw46cmpjhrksr-libtirpc-riscv64-unknown-linux-gnu-1.3.6', '/nix/store/nx5i8n4dvz49qbh2gglzlnbvqsd9qfxp-lmbench-riscv64-unknown-linux-gnu-0.1.0'], 'archive_sha256': '16bf397f903a62b1fb91520f3614887021833af235c5368977b8ef50444e4e0c', 'archive_bytes': 14754669, 'binary_sha256': {'bw_unix': '18dcffafa3e5083ad9a4b6fd8096e3ecd0a35740edc621591976b0dd89d53eec', 'lat_pmake': 'b397f914e7b0907657f6c9af368a6e26771c5c30872d409ccea50d8b878db717', 'lib_stats.o': '80c2aece430a03ebaee3926670cc4c9470ad510dceef59e81995e834d624fb30', 'lib_timing.o': 'bcd2f51cbd127ab23e8c3f5e7cc4be49883175b875e14fe04dfbecb63b814671', 'msleep': 'bb50b58999d1e8a74438cff51bbd256c8f9b6fd2462e209e471085dca79e1f18', 'hello': '8a8f6e16edaa74f6b70d06555f8dd13d7ba4629100e834dcdb7494e7590b430c', 'lat_pagefault': 'ab14d4bfa26e5a0384ed0678ffa35d9f73c065d1ff295ab62c772a228db3fdaa', 'lat_rpc': 'baad9f0281f2e948eda0f950acc2fd8506530ccbbf676167cc4a7c19c0dd3908', 'lib_tcp.o': 'e6207d5b1983387525b60920d14f373b165e9283c0370cdaf6730d832f4e0f34', 'stream': 'e3dd758c6db4ed9dd060217dcdc966999ffd65c1eb343d5768ddece5e5f15969', 'lat_sig': '72c2701a3f8cf655f2453950c931da8e4c3637765aceb276d6ec4bbef7541a7f', 'lib_unix.o': '7134e6ce260d3eae260e84b187bb7e6794ccfa662949f3f9192429369ac50f8f', 'lat_select': 'da9833e0e60e4d8eaf8517bb768cba4556b727ab324300f6e2a6a93a09965abc', 'lib_debug.o': '7e0c99b485c040c665cba505f4cc5f47880e3f539b5b17cc59bc94aa8087fc37', 'lat_cmd': 'f13f5aeff8201b1db60a1eee3a024517a6dcbba579b48e566afe81b131bc843f', 'lat_syscall': '78c53462312dd1ca2a271cb06a9902564150219040b4c592e44fc263304d3673', 'par_mem': 'dffd5b50fb5659bd8c87c5258f27f048b20ece7d5365ac99ccbd643d47bf6b0a', 'memsize': 'a1d47b29d20c0ef2192f69298f58921dcebd6f4181bd98523996837971b117e8', 'bw_file_rd': '1b1d776a4774cba03acfdf49b05112446162f77226f72dd67b72b8aae31e9fce', 'par_ops': '0dd2565f3fbcc38ba4bae69217552b08baf41564c6f64cf4b5ecb366caca5058', 'lat_fs': 'b6d9ba7982fc28575015686308dcf8af1a7202dbc2b9e8b1c837e64d6a42a5d3', 'lmdd': '7d28183910606d8d1d4914a1d528fd9fa62e7cbc77616925bb94fcc64e1d3d80', 'lat_ops': 'd038edf2b9c446f62c4ad1d5a26b0071d179eb8eb9af44f758fb6569b0f0b77c', 'lat_connect': 'ebc904d15d56777b2534ec07f79ef02bf1d43157ae6fe1d61104ed51c7c4657d', 'cache': '086b2d870cc84a296ba94b639747e847921a13d1bcb66981468699d361f82f80', 'lmhttp': '8dbd00720e77684ca8f4233a793160e91fc6281e4d8238a59d9eaed866bc5d3a', 'lat_rand': 'd4999838facc4c24178028fe7ab3801b66a99748d86f0f0f1c8268c94888a175', 'lat_mmap': '655299edfe4a4be05e8b129c0324eb673c61bfd876e292bfdb685c61838bde78', 'bw_mmap_rd': '0575ec36ed7a1f68cb9fa48547b7e55b241f55c43c4b01217c001bb7c8e5b447', 'disk': '4fa74bb2b9c2e9122ca461b95be5795b4a622d47e934efd003de8a43ae1460e1', 'loop_o': 'f695651b2600825e22d2ccd4f432e7556599869c474c29701f7f4966d5209ec5', 'getopt.o': '29db516b16aa3db2c8a4585bb0789858a0b32c5149fe960556fbce75bda43158', 'lat_unix_connect': '4b65fe6b2dee34f5c1092faa711a1fc9318aff2243c1fbaa11d3ca650b7bf391', 'lat_sem': '5eda856d6e2b4d40ae76970ead67c1cc61e356b8f5e98adaa79090237cc6933c', 'lat_tcp': '363307ce2ce8a41259c2859f731a1b7588f0861f47058ee954782c4cdd4b77e3', 'lat_fcntl': 'a7a23f74cb9a7a9f93ea4e151d2bd4c668ac4a87dd15a8c74ffd6c780da7a931', 'flushdisk': '5e766e43d3ab32378a3eeec990c04530f5ace8111ab83a65208fd05bd55e3155', 'lat_http': '6cb15480d489624df8fefeb1b6749df37dd28023d86949cb79004a1a1b02afd1', 'lib_mem.o': '5df205a7f7c9fefe587b784bd24d8ff05b9adbdaa7933fde14da1d1edc37f9c7', 'lat_unix': 'f9755bc0d7af6ca28ae6f71a566d592917ddcde5a0a07396f6ce074d24ea65e8', 'lib_udp.o': '0f4935b1860bb0612599009ee421de72206a62355648a4e8abc66d0570092af0', 'lat_dram_page': '78e9d71fa50c345799c4604489fbc585058fc44a55a7c2c78d9ac24581e0314b', 'lat_usleep': '6721c8192b8d7a06cbb1ecde61b888da5b19865d0a96c5d1c9a4148cf40e7ac4', 'lat_udp': 'a57f785a430d194589c887218182f2ecbaad2b574ef31d89dbb49f537176303e', 'lib_sched.o': '6faa10e8a5df83ab0dee5ab2f76c4de2dd8f6c5f0fe3b6beccd26134054bb471', 'lat_fifo': '7ab3c96eb187bef6876fdd87e3290c24c8b2d80ebd51aa6af6e3e7a27e9f2e77', 'tlb': 'd0575959151850aa4da1ccc4a0f57b11130edf5aa9191d4f8e2f56c683ec5119', 'mhz': '2e664d2fe76a0a3192820e3cfa480ba0fe6cc8de8d251123c9497edd637159e3', 'lat_mem_rd': '08f1851023dd010f038c0328e109a6b3841782bbc8a83974517d581bd08bdd75', 'bw_tcp': 'e687a5eb6fe4e70925e704038d1341f6f85a3897127d2ab00b18e506bb872679', 'lat_proc': '08d49de0c8c56100894ac99b692b26cf8933b784938ab5b31656267dbf5260c8', 'lat_pipe': 'c7beb523f0bf9d98dd78862fa453d2363f6c903f89d79b4f231725a840a98a88', 'lat_ctx': 'd3b2a6ff6bab80a5163b0cd669fe114c7d3a545bbfca68fdc56e5b9cfa0a4b88', 'bw_pipe': '9a663b3cf7029e1af1bedc3c8b098449886bea5a73835c61ee65775ae27927e8', 'bw_mem': '65da5ccb1bf084843bd15c9585175f90acd75e7111358e0cd8bb24892c3506eb', 'line': 'e2aa02ccb5a45667e1dbf8f3d9e9819a77a5178ebf4c0119ae1926eee15b9c7f', 'timing_o': '76bd4bf604d97cc9f55457e660870e821c1f29948cd2b30aeb7f232d95378af4', 'enough': 'a685df10c7ce692e247e37fb6d68fdc7970ece3f4ed28700e79f3891d213a8da'}}
archive=Path('/opt/lmbench-runtime.tar.gz')
assert hashlib.sha256(archive.read_bytes()).hexdigest()==meta['archive_sha256']
subprocess.run(['tar','xzf',str(archive),'-C','/'],check=True,timeout=20)
bindir=Path(meta['package'])/'bin'
for name in ['lat_syscall','lat_proc','lat_pipe','lat_ctx','lat_sig','bw_mem','lat_mmap','lat_pagefault','hello']:
    assert hashlib.sha256((bindir/name).read_bytes()).hexdigest()==meta['binary_sha256'][name],name
emit('identity',{'kernel':os.uname().release,'arch':os.uname().machine,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'bundle':meta['archive_sha256']})
subprocess.run(['systemctl','stop','asterinas-desktop-m5.service'],check=True,timeout=6)
fixture=Path('/tmp/lmbench-basic-file');fixture.write_bytes(b'x'*(1024*1024))
shutil.copyfile(bindir/'hello','/tmp/hello');Path('/tmp/hello').chmod(0o755)
for cmd in [['/tmp/hello'],['/bin/sh','-c','/tmp/hello']]:
    p=subprocess.run(cmd,env={},capture_output=True,text=True,timeout=3)
    assert p.returncode==0 and 'hello' in p.stdout.lower(),(cmd,p.returncode,p.stdout,p.stderr)
    emit('exec-preflight',{'argv':cmd,'status':p.returncode,'stdout':p.stdout})
common=['-P','1','-W','0','-N','1']
cases=[]
for mode in ['null','read','write','stat','fstat','open']:
    args=['lat_syscall']+common+[mode]
    if mode in ['stat','fstat','open']:args.append(str(fixture))
    cases.append(('syscall-'+('getppid' if mode=='null' else mode),args,r'(Simple [^\n]+): ([0-9.]+) microseconds'))
for mode in ['fork','exec','shell']:
    cases.append(('process-'+mode,['lat_proc']+common+[mode],r'(Process [^\n]+): ([0-9.]+) microseconds'))
cases += [('pipe',['lat_pipe']+common,r'(Pipe latency): ([0-9.]+) microseconds'),('context-switch-2',['lat_ctx']+common+['-s','0','2'],r'(?m)^2\s+([0-9.]+)\s*$')]
for mode in ['install','catch']:
    cases.append(('signal-'+mode,['lat_sig']+common+[mode],r'([^\n]+): ([0-9.]+) microseconds'))
for mode in ['rd','wr','cp']:
    cases.append(('memory-'+mode,['bw_mem']+common+['1m',mode],r'(?m)^1\.0+\s+([0-9.]+)\s*$'))
cases += [('mmap',['lat_mmap']+common+['1m',str(fixture)],r'(?m)^1\.0+\s+([0-9.]+)\s*$'),('pagefault',['lat_pagefault']+common+[str(fixture)],r'([^\n]+): ([0-9.]+) microseconds')]
env=os.environ.copy();env.update(ENOUGH='10000',LC_ALL='C')
failed=[]
for name,args,pattern in cases:
    argv=[str(bindir/args[0])]+args[1:];start=time.monotonic()
    emit('case-start',{'name':name,'argv':argv})
    p=subprocess.Popen(argv,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
    timeout=False
    try:stdout,stderr=p.communicate(timeout=10)
    except subprocess.TimeoutExpired:
        timeout=True;os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate(timeout=3)
    found=re.search(pattern,stdout+stderr)
    passed=p.returncode==0 and not timeout and found is not None and math.isfinite(float(found.groups()[-1])) and float(found.groups()[-1])>0
    record={'name':name,'argv':argv,'elapsed':round(time.monotonic()-start,3),'status':p.returncode,'timeout':timeout,'stdout':stdout,'stderr':stderr,'passed':passed}
    emit('case-result',record)
    if not passed:
        failed.append(name)
        break
emit('complete',{'passed':not failed,'failed':failed,'planned_cases':len(cases)})
assert not failed,failed
