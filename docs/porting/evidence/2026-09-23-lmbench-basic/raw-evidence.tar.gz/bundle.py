from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path('/root/asterinas')
out=root/'target/lmbench-basic-20260923'
pkg=Path('/nix/store/nx5i8n4dvz49qbh2gglzlnbvqsd9qfxp-lmbench-riscv64-unknown-linux-gnu-0.1.0')
closure=subprocess.check_output(['nix-store','-qR',str(pkg)],text=True).splitlines()
archive=out/'lmbench-runtime.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in closure:tar.add(p,arcname=p.lstrip('/'))
meta={'source_rev':'afb47eddaf10a411c1ea3cb64965461f1308a6ea','package':str(pkg),'closure':closure,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'binary_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (pkg/'bin').iterdir() if p.is_file() and p.read_bytes()[:4]==b'\x7fELF'}}
(out/'bundle.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({k:meta[k] for k in ['package','archive_sha256','archive_bytes']}))
