import json, os, subprocess, time
from pathlib import Path

UNIT = 'asterinas-desktop-m5.service'
START = time.monotonic()
def emit(kind, value):
    print('LIFECYCLE '+json.dumps({'kind':kind,'elapsed':round(time.monotonic()-START,3),'value':value}),flush=True)
def read(path):
    try: return Path(path).read_text()[:16000]
    except OSError as e: return type(e).__name__+': '+str(e)
def command(args):
    try:
        p=subprocess.run(args,capture_output=True,text=True,timeout=4)
        return {'argv':args,'status':p.returncode,'stdout':p.stdout[:20000],'stderr':p.stderr[:2000]}
    except subprocess.TimeoutExpired: return {'argv':args,'timeout':True}
def snapshot(label):
    props=['MainPID','ControlPID','ControlGroup','ActiveState','SubState','Result','KillMode','KillSignal','SendSIGKILL','TimeoutStopUSec','Type','ExecMainCode','ExecMainStatus']
    state=command(['systemctl','show',UNIT]+['--property='+p for p in props]);emit(label+'-unit',state)
    cg=''
    for line in state.get('stdout','').splitlines():
        if line.startswith('ControlGroup='): cg=line.split('=',1)[1]
    if cg:
        emit(label+'-cgroup',{n:read('/sys/fs/cgroup'+cg+'/'+n) for n in ['cgroup.procs','cgroup.threads','cgroup.events']})
    processes=[]
    keys={'Name','State','Pid','PPid','Tgid','Threads','SigPnd','ShdPnd','SigBlk','SigIgn','SigCgt'}
    for d in sorted(Path('/proc').iterdir(),key=lambda p:p.name):
        if not d.name.isdecimal(): continue
        status={k:v.strip() for line in read(d/'status').splitlines() if ':' in line for k,v in [line.split(':',1)] if k in keys}
        if not status: continue
        item={'status':status,'cmdline':read(d/'cmdline').replace('\x00',' '),'cgroup':read(d/'cgroup')}
        if status.get('Name') in ('systemd','bash','Xorg','openbox','tail','runuser','sleep'):
            item['tasks']={t.name:{n:read(t/n) for n in ['stat','asterinas_syscall','wchan','stack']} for t in (d/'task').iterdir()}
        processes.append(item)
    emit(label+'-processes',processes)
emit('unit-definition',command(['systemctl','cat',UNIT]))
snapshot('before')
emit('stop-command',command(['systemctl','stop','--no-block',UNIT]))
time.sleep(1);snapshot('after-1s')
time.sleep(3);snapshot('after-4s')
emit('awaiting-cpu-capture','ready')
deadline=time.monotonic()+15
while not Path('/run/lifecycle-captured').exists() and time.monotonic()<deadline: time.sleep(.1)
emit('journal',command(['journalctl','-u',UNIT,'-n','30','--no-pager']))
emit('complete','collected')
