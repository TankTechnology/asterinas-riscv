import ctypes, json, os, select, struct, time
from pathlib import Path

libc=ctypes.CDLL(None,use_errno=True)
libc.inotify_init1.argtypes=[ctypes.c_int];libc.inotify_init1.restype=ctypes.c_int
libc.inotify_add_watch.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_uint32];libc.inotify_add_watch.restype=ctypes.c_int
def checked(n):
    if n<0: raise OSError(ctypes.get_errno(),os.strerror(ctypes.get_errno()))
    return n
root=Path('/sys/fs/cgroup')/('asterinas-events-'+str(os.getpid()))
leaf=root/'child';root.mkdir();leaf.mkdir()
fd=checked(libc.inotify_init1(os.O_NONBLOCK|os.O_CLOEXEC))
pins=[];watches=[]
def emit(kind,value): print('LIFECYCLE '+json.dumps({'kind':kind,'value':value}),flush=True)
def events():
    poll=select.poll();poll.register(fd,select.POLLIN);ready=poll.poll(250)
    if not ready:return []
    data=os.read(fd,4096);result=[];offset=0
    while offset<len(data):
        wd,mask,cookie,length=struct.unpack_from('iIII',data,offset);offset+=16+length
        result.append({'wd':wd,'mask':mask})
    return result
try:
    for group in (root,leaf):
        pin=os.open(group/'cgroup.events',os.O_RDONLY);pins.append(pin)
        watches.append(checked(libc.inotify_add_watch(fd,('/proc/self/fd/'+str(pin)).encode(),2)))
    emit('watch-pinned',watches)
    pipe=os.pipe();child=os.fork()
    if child==0:
        os.close(pipe[1]);os.read(pipe[0],1);os._exit(0)
    os.close(pipe[0])
    (leaf/'cgroup.procs').write_text(str(child))
    entered=events();emit('entered',{'events':entered,'states':[p.joinpath('cgroup.events').read_text() for p in (root,leaf)]})
    os.write(pipe[1],b'x');os.close(pipe[1]);os.waitpid(child,0)
    exited=events();emit('exited',{'events':exited,'states':[p.joinpath('cgroup.events').read_text() for p in (root,leaf)]})
    # Reopening an existing attribute should preserve its inotify identity.
    identity=checked(libc.inotify_init1(os.O_NONBLOCK|os.O_CLOEXEC))
    first=checked(libc.inotify_add_watch(identity,str(leaf/'cgroup.events').encode(),2))
    second=checked(libc.inotify_add_watch(identity,str(leaf/'cgroup.events').encode(),2))
    emit('watch-path-identity',{'first':first,'second':second});os.close(identity)
    assert all(any(e['wd']==wd and e['mask']&2 for e in entered) for wd in watches), 'populated entry notifications missing'
    assert all(any(e['wd']==wd and e['mask']&2 for e in exited) for wd in watches), 'populated exit notifications missing'
    assert first==second, 'attribute inode identity changed on lookup'
    emit('complete','pass')
finally:
    for pin in pins:os.close(pin)
    os.close(fd)
    leaf.rmdir();root.rmdir()
