import base64, json, os, runpy, socket, struct, sys, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
sys.path.insert(0,'/usr/lib/asterinas')
from browser_m5_marionette_gate import Marionette
production=runpy.run_path('/usr/lib/asterinas/browser-web-marionette-gate')
exec('def _playback_probe(client: Marionette) -> dict[str, object]:\n    # Promise handlers and event counters live on the sandbox\'s video wrapper.\n    # Keep that wrapper across samples, separate from read-only DOM snapshots\n    # that recreate the default sandbox.\n    response = client.command(\n        "WebDriver:ExecuteScript",\n        {\n            "script": _BILIBILI_PLAYBACK_SCRIPT,\n            "args": [],\n            "newSandbox": False,\n            "sandbox": "asterinas-bilibili-playback",\n            "line": 1,\n            "filename": "asterinas-bilibili-playback",\n        },\n    )\n    value = _script_value(response)\n    if not isinstance(value, str):\n        detail = repr(response)\n        if len(detail) > 256:\n            detail = detail[:253] + "..."\n        raise GateError(\n            "Bilibili playback script returned no JSON: "\n            f"response_type={type(response).__name__} response={detail}"\n        )\n    try:\n        parsed = json.loads(value)\n    except json.JSONDecodeError as error:\n        raise GateError("Bilibili playback script returned malformed JSON") from error\n    return _playback_sample_mapping(parsed)\n',production)
VIDEO=base64.b64decode('GkXfo59ChoEBQveBAULygQRC84EIQoKEd2VibUKHgQJChYECGFOAZwEAAAAAAAJWEU2bdLpNu4tT\nq4QVSalmU6yBoU27i1OrhBZUrmtTrIHGTbuMU6uEElTDZ1OsggEiTbuMU6uEHFO7a1OsggJA7AEA\nAAAAAABZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\nAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVSalmoCrXsYMPQkBNgIRMYXZm\nV0GETGF2ZkSJiECPQAAAAAAAFlSua9euAQAAAAAAAE7XgQFzxYgAAAAAAAAAAZyBACK1nIN1bmSI\ngQCGhVZfVlA4g4EBI+ODhAvrwgDgkLCBoLqBWpqBAlWwhFW5gQFV7oEA7AEAAAAAAAACAAASVMNn\n0HNzzWPAi2PFiAAAAAAAAAABZ8iYRaOHRU5DT0RFUkSHi0xhdmMgbGlidnB4Z8ihRaOIRFVSQVRJ\nT05Eh5MwMDowMDowMS4wMDAwMDAwMDAAH0O2dUDD54EAo9aBAACA8AUAnQEqoABaAABHCIWFiIWE\niAICAnWqA/gCBpoT4Iaqk13EOqpNdxDqqTXcQ6qk13EOqpNdxBgA/v9NEv/8WFfxYV/FhX/xYV/8\n/M7txfzmAKOYgQDIABECAAcQ7AAYABhYL/QACICBAAAAo5iBAZAAEQIABxDsABgAGFgv9AAIgIEA\nAACjmIECWAARAgAHEOwAGAAYWC/0AAiAgQAAAKOYgQMgABECAAcQ7AAYABhYL/QACICBAAAAHFO7\na5G7j7OBALeK94EB8YIBd/CBAw==\n')
close_response=threading.Event();requested=threading.Event()
START=time.monotonic()
def emit(kind,value): print('LIFECYCLE '+json.dumps({'kind':kind,'elapsed':round(time.monotonic()-START,3),'value':value}),flush=True)
HTML=b'''<!doctype html><title>Connection close probe</title>
<video muted width=320 height=180></video><button id=retry onclick="start(false)">Retry</button><button id=control onclick="this.textContent='clicked'">Control</button><p id=status></p>
<script>
const v=document.querySelector('video');window.testState={ticks:0,phase:'init',events:{}};
setInterval(()=>testState.ticks++,100);
for(const n of ['playing','waiting','timeupdate','ended','error'])v.addEventListener(n,()=>testState.events[n]=(testState.events[n]||0)+1);
async function append(sb,data){await new Promise((resolve,reject)=>{sb.addEventListener('updateend',resolve,{once:true});sb.addEventListener('error',reject,{once:true});sb.appendBuffer(data);});}
async function start(broken){
 testState.phase=broken?'initial':'retry';testState.networkError=null;
 const ms=new MediaSource();v.src=URL.createObjectURL(ms);
 try{
  await new Promise(r=>ms.addEventListener('sourceopen',r,{once:true}));
  const sb=ms.addSourceBuffer('video/webm; codecs="vp8"');
  await append(sb,await(await fetch('/clip')).arrayBuffer());await v.play();testState.phase='playing';
  const bytes=await(await fetch(broken?'/broken':'/clip')).arrayBuffer();
  sb.timestampOffset=sb.buffered.end(sb.buffered.length-1);await append(sb,bytes);ms.endOfStream();testState.phase='complete-source';
 }catch(e){testState.networkError=String(e);testState.phase='network-error';document.querySelector('#status').textContent='Connection interrupted';}
}
start(true);
</script>'''
class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def do_GET(self):
        if self.path=='/broken':
            self.send_response(200);self.send_header('Content-Length',str(len(VIDEO)));self.end_headers()
            self.wfile.write(VIDEO[:32]);self.wfile.flush();requested.set()
            if not close_response.wait(20): raise TimeoutError('close trigger did not arrive')
            self.connection.setsockopt(socket.SOL_SOCKET,socket.SO_LINGER,struct.pack('ii',1,0));self.connection.close();self.close_connection=True
            emit('server-close',{'declared_bytes':len(VIDEO),'sent_bytes':32,'termination':'zero-linger-reset'});return
        body=VIDEO if self.path=='/clip' else HTML
        self.send_response(200);self.send_header('Content-Length',str(len(body)));self.send_header('Content-Type','video/webm' if self.path=='/clip' else 'text/html');self.end_headers();self.wfile.write(body)
    def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',18766),Handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
client=Marionette('127.0.0.1',2828,120)
session=client.command('WebDriver:NewSession',{'strictFileInteractability':True,'proxy':{'proxyType':'direct'}});emit('session',session)
pid=session['capabilities']['moz:processID']
def execute(script):
    client.set_timeout(12)
    r=client.command('WebDriver:ExecuteScript',{'script':script,'args':[],'newSandbox':True,'sandbox':'default'})
    return r.get('value',r) if isinstance(r,dict) else r
def sample(label):
    client.set_timeout(12);s=production['_playback_probe'](client)
    p=json.loads(execute('return JSON.stringify(window.wrappedJSObject.testState);'))
    emit(label,{'probe':s,'page':p});return s,p
client.set_timeout(30);client.command('WebDriver:Navigate',{'url':'http://127.0.0.1:18766/'})
deadline=time.monotonic()+15
while time.monotonic()<deadline:
    s,p=sample('before-close')
    if requested.is_set() and s['currentTime']>.25:break
    time.sleep(.2)
else:raise RuntimeError('initial playback not observed')
close_response.set();deadline=time.monotonic()+12
while time.monotonic()<deadline:
    s,p=sample('after-close')
    if p['phase']=='network-error' and s['readyState']<=2 and p['events'].get('waiting',0):break
    time.sleep(.2)
else:raise RuntimeError('no bounded connection error and media waiting')
assert execute("document.querySelector('#control').click(); return document.querySelector('#control').textContent;")=='clicked'
assert execute("return document.querySelector('#status').textContent;")=='Connection interrupted'
emit('connection-error-ui','pass')
execute("document.querySelector('#retry').click(); return true;")
deadline=time.monotonic()+12
while time.monotonic()<deadline:
    s,p=sample('retry')
    if p['phase']=='complete-source' and s['currentTime']>1.25 and s['decodedFrames']>4:break
    time.sleep(.2)
else:raise RuntimeError('explicit retry did not play new media')
emit('retry-playback','pass')
client.set_timeout(12);emit('quit-response',client.command('Marionette:Quit',{'flags':['eAttemptQuit']}));client.close()
deadline=time.monotonic()+10
while Path('/proc/'+str(pid)).exists() and time.monotonic()<deadline:time.sleep(.1)
emit('browser-exit',{'pid':pid,'exited':not Path('/proc/'+str(pid)).exists()})
assert not Path('/proc/'+str(pid)).exists(),'Firefox did not exit'
server.shutdown();emit('complete','pass')
